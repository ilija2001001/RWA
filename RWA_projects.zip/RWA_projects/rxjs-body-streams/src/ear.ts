import { Observable, interval, map } from "rxjs";
import { Side } from "./side";
import { SAMPLE_RATE } from ".";

export class Ear {
    private _side: Side;
    sound$: Observable<string>;

    constructor(side: Side) {
        this._side = side;
        this.sound$ = interval(SAMPLE_RATE).pipe(
            map(()=> 'Sound' + this._side)
        )
    }

    get side() { return this._side;}

    
}