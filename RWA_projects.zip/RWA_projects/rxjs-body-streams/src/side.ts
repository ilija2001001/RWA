export enum Side {
    Left = 'Left',
    Right = 'Right'
}