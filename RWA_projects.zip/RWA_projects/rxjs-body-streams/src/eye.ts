//otvori/zatvori oci
import { Observable, interval, map } from "rxjs";
import { Side } from "./side";
import { SAMPLE_RATE } from ".";

export class Eye {
    private _side: Side;
    image$: Observable<string>;

    constructor(side: Side) {
        this._side = side;
        this.image$ = interval(SAMPLE_RATE).pipe(
            map(()=> 'Image' + this._side)
        )
    }

    get side() { return this._side;}

    
}