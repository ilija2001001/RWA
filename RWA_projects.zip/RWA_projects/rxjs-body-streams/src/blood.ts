import { Observable, Subject, interval, map } from "rxjs";
import { SAMPLE_RATE } from ".";
import { AdrenalGlands } from "./adrenal_glands";
import { Brain } from "./brain";

export class Blood {
    numErythrocytes: number;
    numLeukocytes: number;
    numTrombocytes: number;
    adrenaline: number;

    bloodFlow$: Subject<number>;
    adrenalGlandsImpulse$: Subject<number>

    constructor(adrenalGlands: AdrenalGlands, numErythrocytes:number = 50, numLeukocytes: number = 40, numTrombocytes: number = 30, adrenaline: number = 0) {
        this.numErythrocytes = numErythrocytes;
        this.numLeukocytes = numLeukocytes;
        this.numTrombocytes = numTrombocytes;
        this.adrenaline = adrenaline;

        this.bloodFlow$ = new Subject<number>();

        this.adrenalGlandsImpulse$ = adrenalGlands.adrenalGlandsImpulse$;
        this.adrenalGlandsImpulse$.subscribe(x => {
            if (x === 11111101) {
                console.log("Blood: Releasing adrenaline...");
                this.bloodFlow$.next(11111101);
            }
        });
        
    }
}