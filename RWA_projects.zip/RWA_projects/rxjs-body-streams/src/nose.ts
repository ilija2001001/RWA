import { Observable, interval, map } from "rxjs";
import { SAMPLE_RATE } from ".";

export class Nose {
    smell$: Observable<string>;

    constructor() {
        this.smell$ = interval(SAMPLE_RATE).pipe(
            map(()=> 'Smell')
        )
    }
    
}