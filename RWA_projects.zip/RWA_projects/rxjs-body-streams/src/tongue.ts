import { Observable, interval, map } from "rxjs";
import { SAMPLE_RATE } from ".";

export class Tongue {
    taste$: Observable<string>;

    constructor() {
        this.taste$ = interval(SAMPLE_RATE).pipe(
            map(()=> 'Taste')
        )
    }
    
}

export enum Taste {
    Sweet = 'Sweet',
    Sour = 'Sour',
    Bitter = 'Bitter',
    Salty = 'Salty'
}