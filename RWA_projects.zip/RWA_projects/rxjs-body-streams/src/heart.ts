import { Subject, delay, filter, interval, startWith, tap, timer } from "rxjs";
import { Blood } from "./blood";

export class Heart { 
    
    private _BPM: number;
    private heartIcon: HTMLElement;
    private bpmCount: HTMLElement;

    constructor(blood: Blood, BPM: number = 90) {
        this._BPM = BPM;
        this.heartIcon = document.getElementById("heart");
        this.bpmCount = document.getElementById("bpm-value");
        

        interval(60000 / BPM)
          .subscribe(() => {
            console.log("Heartbeat - BPM: " + this.BPM);
            if (Math.round(Math.random() * 10) > 5) {
                this.increaseBPM();
            } else {
                this.decreaseBPM();
            }
            this.bpmCount.innerHTML = `${this.BPM}`;
            this.animateHeartbeat();
        });

        blood.bloodFlow$.pipe(
          filter(x => x === 11111101),
          tap(() => {
            console.log("Heart: Increasing BPM...");
            this._BPM = 160 + Math.round(Math.random() * 10);
            console.log("Heartbeat - BPM: " + this.BPM);
            this.bpmCount.innerHTML = `${this.BPM}`;
            this.animateHeartbeat();
          }),
          delay(5000))
          .subscribe(() => {
            this._BPM = 90;
            console.log("Heartbeat - BPM: " + this.BPM);
            this.bpmCount.innerHTML = `${this.BPM}`;
            this.animateHeartbeat();
          });
    }

    get BPM(): number { return this._BPM; }
    set BPM(newBPM: number) { this._BPM = newBPM; }

    public increaseBPM() { this._BPM++; }
    public decreaseBPM() { this._BPM--; }

    private animateHeartbeat() {
        this.heartIcon.style.filter = "brightness(200%)";
        setTimeout(() => {
            this.heartIcon.style.filter = "brightness(100%)";
        }, 50);
    }
}
