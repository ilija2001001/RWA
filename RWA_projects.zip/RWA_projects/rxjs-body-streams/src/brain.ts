import { Observable, Subject, Subscription, concat, filter, interval, map, take, takeUntil } from "rxjs";
import { SAMPLE_RATE } from ".";
import { Heart } from "./heart";
import { AdrenalGlands } from "./adrenal_glands";

export const brainActions: string[] = ["Open eyes", "Move left hand", "Move right hand", "Move left leg", "Move right leg", "Move head", "Rotate neck"];

export class Brain {
    brainImpuls$: Subject<[string, string] | string | number>;
    neuralImpuls$: Observable<[string, string] | string | number>;

    Thought$: Observable<number>;
    Fear$: Observable<number>
    Memorie$: Observable<number>;
    Information$: Observable<number>;
    cognitiveProcesse$: Observable<number>;
    cognitiveProcessesSub: Subscription;

    sleeping: Subject<number>;

    Dream$: Observable<number>;
    
    private wakefulness: Subscription;
    private brainIcon: HTMLElement;
    private brainInfo: HTMLElement;

    constructor(neuralBus$: Observable<[string, string] | string | number>) {
        this.brainImpuls$ = new Subject<string>();
        this.sleeping = new Subject<number>();
        this.neuralImpuls$ = neuralBus$;
        this.brainIcon = document.getElementById("brain");
        this.brainInfo = document.getElementById("brain-info");
        
        neuralBus$.subscribe(x => {
            this.brainImpuls$.next(x);
        });

        neuralBus$.pipe(filter(x => x === "Touch")).subscribe(x => {
            const randomNumber = Math.round(Math.random() * 6);
            this.brainImpuls$.next(brainActions[randomNumber]);
        });
    }

    public wakeUp() {
        this.wakefulness = this.brainImpuls$.subscribe(x => console.log(x));
        this.cognitiveProcceses();
    }

    public sleep() {
        this.brainInfo.innerHTML = `Sleeping...`;
        this.sleeping.next(0);
        this.brainImpuls$.complete();
        this.wakefulness.unsubscribe();
        this.cognitiveProcessesSub.unsubscribe();
        console.log("Brain: Sleeping...");
    }

    public cognitiveProcceses() {
        this.Thought$ = interval(Math.round(Math.random() * 1000)).pipe(
            map(x => x = 0),
            take(Math.round(Math.random() * 10)));
        this.Fear$ = interval(Math.round(Math.random() * 1000)).pipe(
            map(x => x = 1),
            take(Math.round(Math.random() * 10)));
        this.Memorie$ = interval(Math.round(Math.random() * 1000)).pipe(
            map(x => x = 1),
            take(Math.round(Math.random() * 10)));
        this.Information$ = interval(Math.round(Math.random() * 1000)).pipe(
            map(x => x = 2),
            take(Math.round(Math.random() * 10)));

        this.cognitiveProcesse$ = concat(this.Thought$, this.Fear$, this.Information$, this.Memorie$);
        this.cognitiveProcessesSub = this.cognitiveProcesse$.subscribe(x => {
            if (x === 0) {
                console.log("Brain: Thinking...");
                this.brainInfo.innerHTML = `Thinking...`;
                this.animateBrain();
            } else if (x === 1) {
                console.log("Brain: Fear...");
                this.brainInfo.innerHTML = `Fear...`;
                this.animateBrain();
            } else if (x === 2) {
                console.log("Brain: Memorising...");
                this.brainInfo.innerHTML = `Memorising...`;
                this.animateBrain();
            } else { 
                console.log("Brain: Processing information...");
                this.brainInfo.innerHTML = `Processing information...`;
                this.animateBrain();
            }
        });
    }

    private animateBrain() {
        this.brainIcon.style.filter = "brightness(200%)";
        setTimeout(() => {
            this.brainIcon.style.filter = "brightness(100%)";
        }, 100);
    }
}
