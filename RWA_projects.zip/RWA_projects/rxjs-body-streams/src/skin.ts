import { Observable, fromEvent, map } from "rxjs";

export class Skin {
    touch$: Observable<string>;
    constructor() {
        this.touch$ = fromEvent(document, 'keydown').pipe(
            map(()=> 'Touch')
        )
    }


}