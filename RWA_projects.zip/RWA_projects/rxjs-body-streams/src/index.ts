import { Observable, interval, merge, zip } from "rxjs";
import { Ear } from "./ear";
import { Side } from "./side";
import { Eye } from "./eye";
import { Nose } from "./nose";
import { Tongue } from "./tongue";
import { Skin } from "./skin";
import { Brain } from "./brain";
import { MuscularSystem } from "./muscular_system";
import { Heart } from "./heart";
import { AdrenalGlands } from "./adrenal_glands";
import { Blood } from "./blood";
import { BodyPreview } from "./body_preview";

export const SAMPLE_RATE = 1000/24;

const bodyPreview: BodyPreview = new BodyPreview();

const earLeft = new Ear(Side.Left);
const earRight = new Ear(Side.Right);
const stereoSound$ = zip(earLeft.sound$, earRight.sound$);  //sinhronizacija oba uha

const eyeLeft = new Eye(Side.Left);
const eyeRight = new Eye(Side.Right);
const stereoImages$: Observable<[string, string]> = zip(eyeLeft.image$, eyeRight.image$);  ///sinhronizacija oba oka

const nose: Nose = new Nose();

const tongue: Tongue = new Tongue();

const skin: Skin = new Skin();

const neuralBus$: Observable<[string, string] | string | number> = merge(stereoSound$, stereoImages$, nose.smell$, tongue.taste$, skin.touch$, interval(SAMPLE_RATE));


const brain: Brain = new Brain(neuralBus$);

brain.wakeUp();

const adrenalGlands: AdrenalGlands = new AdrenalGlands(brain);


const circlulatorySystem: Blood = new Blood(adrenalGlands);

const muscularSystem: MuscularSystem = new MuscularSystem(brain);



const heart: Heart = new Heart(circlulatorySystem);





setTimeout(() => {
    brain.sleep()
}, 15000);