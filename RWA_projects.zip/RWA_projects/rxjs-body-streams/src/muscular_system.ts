import { filter, map } from "rxjs";
import { Brain, brainActions } from "./brain";

 export class MuscularSystem {
   
    constructor(brain: Brain) {

        brain.brainImpuls$.pipe(
            filter((x: string) => brainActions.includes(x) === true)
        ).subscribe(x => {
            console.log("Muscle action: " + x);
        });
    }
 }

 export enum MuscleState {
    Relaxed = "Relaxed",
    Contracted = "Contracted"
 }