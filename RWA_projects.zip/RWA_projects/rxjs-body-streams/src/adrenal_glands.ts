import { Observable, Subject, Subscription, filter, takeUntil } from "rxjs";
import { Brain } from "./brain";
import { Blood } from "./blood";

export class AdrenalGlands {

    adrenalGlandsImpulse$: Subject<number>;
    private kidneysIcon: HTMLElement;

    constructor(brain: Brain) {
        this.adrenalGlandsImpulse$ = new Subject<number>();
        this.kidneysIcon = document.getElementById("kidneys");

        brain.cognitiveProcesse$.pipe(
            filter(x => x === 1),
            takeUntil(brain.sleeping)
        ).subscribe(x => { 
            console.log("Adrenal glands: Producing adrenaline...");
            this.adrenalGlandsImpulse$.next(11111101);
            this.animateAdrenalGlands();
        });
    }

    private animateAdrenalGlands() {
        this.kidneysIcon.style.filter = "brightness(200%)";
        setTimeout(() => {
            this.kidneysIcon.style.filter = "brightness(100%)";
        }, 1000);
    }
}
