export class BodyPreview {
    constructor() {
        this.draw();
    }

    draw() {
        let main_frame = document.createElement("div");
        main_frame.classList.add("main-frame");
        document.body.appendChild(main_frame);
        main_frame.innerHTML = `
            <img id="body" class="organ" src="src/assets/body.png" />
            <img id="brain" class="organ" src="src/assets/brain.png" />
            <img id="heart" class="organ" src="src/assets/heart.png" />
            <img id="kidneys" class="organ" src="src/assets/kidneys.png" />
        `;
        let bpm_frame = document.createElement("div");
        bpm_frame.classList.add("bpm-frame");
        document.body.appendChild(bpm_frame);
        bpm_frame.innerHTML = `
            <img src="src/assets/heart_icon.png" width="48" />
            <p id="bpm-value">Na</p>
        `;
        let brain_info_frame = document.createElement("div");
        brain_info_frame.classList.add("brain-info-frame");
        document.body.appendChild(brain_info_frame);
        brain_info_frame.innerHTML = `
            <p>Brain: <span id="brain-info"></span></p>
        `;
    }
} 