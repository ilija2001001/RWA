import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SubmarineDetailsComponent } from './submarine-details.component';

describe('SubmarineDetailsComponent', () => {
  let component: SubmarineDetailsComponent;
  let fixture: ComponentFixture<SubmarineDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SubmarineDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SubmarineDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
