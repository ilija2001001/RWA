import { Component, Input, OnInit } from '@angular/core';
import { Actions } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { AppState } from 'src/app/app.state';
import { Submarine, ExperienceRating } from 'src/app/models/submarine';
import { rateSubmarineExpedition } from 'src/app/store/submarine.action';
import { selectSelectedSubmarine } from 'src/app/store/submarine.selector';


@Component({
  selector: 'app-submarine-details',
  templateUrl: './submarine-details.component.html',
  styleUrls: ['./submarine-details.component.scss'],
})
export class SubmarineDetailsComponent implements OnInit {

  private _submarine: Submarine | null = null;
  public xpRating: string[] = ['None', 'Bad', 'Poor', 'Average', 'Good', 'Excellent'];


  @Input()
  set submarine(value) {
    this._submarine = value;
    console.log(this._submarine);
  }

  get submarine() {
    return this._submarine;
  }

  constructor(private store: Store<AppState>) {}

  ngOnInit(): void {
    this.store.select(selectSelectedSubmarine).subscribe((submarine) => {
      if (submarine) {
        this.submarine = submarine;
      }
    });
  }

  selectSubmarine(submarine: Submarine) {
    console.log('Selektovana podmornica je ', submarine);
  }

  rate(id: number) {
    let ratingInput: number = parseFloat((document.getElementById('rating') as HTMLInputElement).value);

    this.store.dispatch(
      rateSubmarineExpedition({
        submarineId: id, 
        rating: ratingInput
      })
    );
  }
}
