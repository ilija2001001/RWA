import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SubmarineListComponent } from './submarine-list.component';

describe('PlaylistComponent', () => {
  let component: SubmarineListComponent;
  let fixture: ComponentFixture<SubmarineListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SubmarineListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SubmarineListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
