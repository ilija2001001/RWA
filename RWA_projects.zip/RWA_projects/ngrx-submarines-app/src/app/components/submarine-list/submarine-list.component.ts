import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable, of } from 'rxjs';
import { AppState } from 'src/app/app.state';
import { Submarine } from 'src/app/models/submarine';
import { SubmarineService } from 'src/app/services/submarine.service';
import { loadSubmarines, selectSubmarine } from 'src/app/store/submarine.action';
import { selectSubmarineList } from 'src/app/store/submarine.selector';

@Component({
  selector: 'app-submarine-list',
  templateUrl: './submarine-list.component.html',
  styleUrls: ['./submarine-list.component.scss'],
})
export class SubmarineListComponent implements OnInit {
  submarine$: Observable<Submarine[]> = of([]);
  constructor(private store: Store<AppState>) {}

  ngOnInit(): void {
    this.store.dispatch(loadSubmarines());
    this.submarine$ = this.store.select(selectSubmarineList);
  }

  selectSubmarine(submarine: Submarine) {
    this.store.dispatch(
      selectSubmarine({
        submarineId: submarine.id,
      })
    );
  }
}
