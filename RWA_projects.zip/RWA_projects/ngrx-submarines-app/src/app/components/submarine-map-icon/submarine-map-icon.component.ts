import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Submarine } from 'src/app/models/submarine';

@Component({
  selector: 'app-submarine-map-icon',
  templateUrl: './submarine-map-icon.component.html',
  styleUrls: ['./submarine-map-icon.component.scss']
})
export class SubmarineMapIconComponent implements OnInit {
  @Input() submarine: Submarine | null = null;
  @Output() onClick: EventEmitter<Submarine> = new EventEmitter<Submarine>();

  constructor() {}

  ngOnInit(): void {}

  clicked() {
    if (this.submarine) {
      this.onClick.emit(this.submarine);
    }
  }
}
