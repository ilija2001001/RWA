import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SubmarineMapIconComponent } from './submarine-map-icon.component';

describe('SubmarineMapIconComponent', () => {
  let component: SubmarineMapIconComponent;
  let fixture: ComponentFixture<SubmarineMapIconComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SubmarineMapIconComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SubmarineMapIconComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
