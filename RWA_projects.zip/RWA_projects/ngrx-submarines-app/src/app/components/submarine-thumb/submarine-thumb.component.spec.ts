import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SubmarineThumbComponent } from './submarine-thumb.component';

describe('SubmarineThumbComponent', () => {
  let component: SubmarineThumbComponent;
  let fixture: ComponentFixture<SubmarineThumbComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SubmarineThumbComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SubmarineThumbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
