import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Submarine } from 'src/app/models/submarine';

@Component({
  selector: 'app-submarine-thumb',
  templateUrl: './submarine-thumb.component.html',
  styleUrls: ['./submarine-thumb.component.scss'],
})
export class SubmarineThumbComponent implements OnInit {
  @Input() submarine: Submarine | null = null;
  @Output() onClick: EventEmitter<Submarine> = new EventEmitter<Submarine>();

  constructor() {}

  ngOnInit(): void {}

  clicked() {
    if (this.submarine) {
      this.onClick.emit(this.submarine);
    }
  }
}
