import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SubmarineMapComponent } from './submarine-map.component';

describe('SubmarineMapComponent', () => {
  let component: SubmarineMapComponent;
  let fixture: ComponentFixture<SubmarineMapComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SubmarineMapComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SubmarineMapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
