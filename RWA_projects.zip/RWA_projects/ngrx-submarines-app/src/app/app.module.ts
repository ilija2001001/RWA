import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { AppComponent } from './app.component';
import { SubmarineListComponent } from './components/submarine-list/submarine-list.component';
import { HttpClientModule } from '@angular/common/http';
import { SubmarineThumbComponent } from './components/submarine-thumb/submarine-thumb.component';
import { SubmarineDetailsComponent } from './components/submarine-details/submarine-details.component';
import { StoreModule } from '@ngrx/store';
import { submarinesReducer } from './store/submarine.reducer';
import { AppState } from './app.state';
import { EffectsModule } from '@ngrx/effects';
import { SubmarineEffects } from './store/submarine.effects';
import { SubmarineMapComponent } from './components/submarine-map/submarine-map.component';
import { SubmarineMapIconComponent } from './components/submarine-map-icon/submarine-map-icon.component';

@NgModule({
  declarations: [
    AppComponent,
    SubmarineListComponent,
    SubmarineThumbComponent,
    SubmarineDetailsComponent,
    SubmarineMapComponent,
    SubmarineMapIconComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    StoreModule.forRoot<AppState>({ submarines: submarinesReducer }),
    StoreDevtoolsModule.instrument({
      maxAge: 25, // Retains last 25 states
      autoPause: true, // Pauses recording actions and state changes when the extension window is not open
    }),
    EffectsModule.forRoot([SubmarineEffects]),
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
