export interface Submarine {
  id: number;
  name: string,
  regNumber: string;
  countryOfReg: string;
  type: string;
  maxCrewNumber: number;
  maxDepthInMeters: number;
  completedExpeditionsCount: number;
  rating: number;
  score: number;
  image: string;
  location: any;
}

export enum SubmarineType {  //odredjuje se na osnovu maxDepth
  Coastal = 'Coastal', 
  MediumDepth = 'Medium depth',
  DeepSea = 'Deep sea'
}

export enum ExperienceRating {   //odredjuje se na osnovu score (0.0 - 5.0)
  None = 'Not rated yet',
  Poor = 'Poor',
  Bad = 'Bad',
  Average = 'Average',
  Good = 'Good',
  Excellent = 'Excellent'
}
