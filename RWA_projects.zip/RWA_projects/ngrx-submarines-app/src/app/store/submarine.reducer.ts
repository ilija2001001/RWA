import { createEntityAdapter, EntityState } from '@ngrx/entity';
import { createReducer, on } from '@ngrx/store';
import { Submarine } from '../models/submarine';
import * as Actions from './submarine.action';

export interface SubmarinesState extends EntityState<Submarine> {
  selectedSubmarine: number;
}

// export interface SongsStateOld {
//   list: Song[],
//   selectedSong: number;
// }

const adapter = createEntityAdapter<Submarine>();

export const initialState: SubmarinesState = adapter.getInitialState({
  selectedSubmarine: 0,
});

export const submarinesReducer = createReducer(
  initialState,
  on(Actions.selectSubmarine, (state, { submarineId }) => {
    return {
      ...state,
      selectedSubmarine: submarineId,
    };
  }),
  on(Actions.loadSubmarinesSuccess, (state, { submarines }) =>
    adapter.setAll(submarines, state)
  ),
  on(Actions.rateSubmarineExpeditionSuccess, (state, { submarineId, rating }) =>
    adapter.updateOne(
      {
        id: submarineId,
        changes: {
          rating,
        },
      },
      state
    )
  )
  // on(Actions.addSong, (state, { song}) => {
  //   return adapter.addOne(song, state);
  // })
);
