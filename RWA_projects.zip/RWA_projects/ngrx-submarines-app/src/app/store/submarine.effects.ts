import { Injectable } from '@angular/core';
import { createEffect, Actions, ofType } from '@ngrx/effects';
import { catchError, map, mergeMap, of } from 'rxjs';
import { SubmarineService } from '../services/submarine.service';
import * as SubmarineActions from './submarine.action';

@Injectable()
export class SubmarineEffects {

  constructor(private actions$: Actions, private submarineService: SubmarineService) {}

  loadSubmarine$ = createEffect(() =>
    this.actions$.pipe(
      ofType(SubmarineActions.loadSubmarines),
      mergeMap(() =>
        this.submarineService.getAll().pipe(
          map((submarines) => SubmarineActions.loadSubmarinesSuccess({ submarines })),
          catchError(() => of({ type: 'load error' }))
        )
      )
    )
  );

  
  rateSubmarine = createEffect(() =>
  this.actions$.pipe(
    ofType(SubmarineActions.rateSubmarineExpedition),
    mergeMap((action) =>
      this.submarineService.rate(action.submarineId, action.rating).pipe(
        map(() => SubmarineActions.loadSubmarines()),
        catchError(() => of({ type: 'load error' }))
      )
    )
  )
  );
}