import { createAction, props } from '@ngrx/store';
import { Submarine, ExperienceRating } from '../models/submarine';

export const loadSubmarines = createAction('Load Submarines');
export const loadSubmarinesSuccess = createAction(
  'Load Submarines Success',
  props<{ submarines: Submarine[] }>()
);
export const selectSubmarine = createAction(
  'Select a submarine',
  props<{ submarineId: number }>()
);

export const rateSubmarineExpedition = createAction(
  'Rate a submarine expedition',
  props<{ submarineId: number; rating: number }>()
);

export const rateSubmarineExpeditionSuccess = createAction(
  'Submarine expedition rated succesfully',
  props<{ submarineId: number; rating: number }>()
);

