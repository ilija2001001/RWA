import { createSelector } from '@ngrx/store';
import { AppState } from '../app.state';
import { Submarine } from '../models/submarine';

export const selectSubmarineFeature = createSelector(
  (state: AppState) => state.submarines,
  (submarines) => submarines
);

export const selectSubmarineIds = createSelector(
  selectSubmarineFeature,
  (submarines) => submarines.ids
);

export const selectSubmarineList = createSelector(
  selectSubmarineFeature, 
  (submarines) => submarines.ids
    .map((id) => submarines.entities[id])
    .filter((submarine) => submarine != null)
    .map((submarine) => <Submarine>submarine)
);

// export const selectSongsDict = createSelector(
//     selectSongsFeature,
//     (songs) => songs.list
// )

export const selectSelectedSubmarineId = createSelector(
  selectSubmarineFeature,
  (submarines) => submarines.selectedSubmarine
);

export const selectSelectedSubmarine = createSelector(
  selectSubmarineFeature,
  selectSelectedSubmarineId,
  (submarines, submarineId) => submarines.entities[submarineId]
);
