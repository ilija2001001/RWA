import { SubmarinesState } from './store/submarine.reducer';

export interface AppState {
  submarines: SubmarinesState;
}
