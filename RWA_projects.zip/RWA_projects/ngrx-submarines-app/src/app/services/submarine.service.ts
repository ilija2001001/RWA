import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Submarine } from '../models/submarine';

@Injectable({
  providedIn: 'root',
})
export class SubmarineService {
  constructor(private httpClient: HttpClient) {}

  getAll() {
    return this.httpClient.get<Submarine[]>(environment.api + '/submarines');
  }

  rate(id: number, score: number) {
    return this.httpClient.patch<Submarine>(environment.api + '/submarines/' + id, {score});
  }
}
