export const environment = {
  production: true,
  api: "http://prodserver.mysite.com:3000"
};
