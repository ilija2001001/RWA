import { Submarine } from "src/submarines/models/submarine.entity";
import { ConnectionOptions } from "typeorm";

export const typeOrmConfig: ConnectionOptions = {
  type: 'postgres',
  host: 'localhost',
  port: 5432,
  username: 'postgres',
  password: 'mysecretpassword',
  database: 'submarines',
  entities: [Submarine],
  synchronize: true,
};
