export class SubmarineDto {
    name: string;
    regNumber: string;
    countryOfReg: string;
    maxCrewNumber: number;
    maxDepthInMeters: number;
    completedExpeditionsCount: number;
    score: number;
    location: string;
  }