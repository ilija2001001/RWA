import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class Submarine {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    name: string;

    @Column()
    regNumber: string;

    @Column()
    countryOfReg: string;

    @Column()
    maxCrewNumber: number;

    @Column()
    maxDepthInMeters: number;

    @Column()
    completedExpeditionsCount: number;

    @Column()
    score: number;

    @Column()
    location: string;
  }
  
  export enum SubmarineType {  //odredjuje se na osnovu maxDepth
    Coastal = 'Coastal', 
    MediumDepth = 'Medium depth',
    DeepSea = 'Deep sea'
  }
  
  export enum ExperienceRating {   //odredjuje se na osnovu score (0.0 - 5.0)
    None = 'Not rated yet',
    Poor = 'Poor',
    Bad = 'Bad',
    Average = 'Average',
    Good = 'Good',
    Excellent = 'Excellent'
  }
  