import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Submarine } from './models/submarine.entity';
import { SubmarineDto } from './models/submarine.dto';

@Injectable()
export class SubmarinesService {

    constructor(
        @InjectRepository(Submarine) private submarineRepository: Repository<Submarine>) {}

    public getAll() {
        return this.submarineRepository.find();
    }

    public getById(id: number) {
        return this.submarineRepository.findOne({ where: {id} });
    }

    public async create(submarineDto: SubmarineDto) {
        const submarine = this.submarineRepository.create(submarineDto);
        return await this.submarineRepository.save(submarine);
    }

    public async remove(id: number) {
        return await this.submarineRepository.delete(id);
    }

    public async update(id: number, dto: SubmarineDto) {
        return await this.submarineRepository.update(id, dto);
    }
}
