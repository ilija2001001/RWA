import { Module } from '@nestjs/common';
import { SubmarinesController } from './submarines.controller';
import { SubmarinesService } from './submarines.service';
import { Submarine } from './models/submarine.entity';
import { TypeOrmModule } from '@nestjs/typeorm';

@Module({
    imports: [TypeOrmModule.forFeature([Submarine])],
    controllers: [SubmarinesController],
    providers: [SubmarinesService],
})
export class SubmarinesModule {}
