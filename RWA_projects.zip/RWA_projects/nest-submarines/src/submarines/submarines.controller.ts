import { Body, Controller, Delete, Get, Param, ParseIntPipe, Post, Put } from '@nestjs/common';
import { SubmarinesService } from './submarines.service';
import { SubmarineDto } from './models/submarine.dto';

@Controller('submarines')
export class SubmarinesController {

    constructor(private submarinesService: SubmarinesService) {}

    @Get()
    public getSubmarines() {
        return this.submarinesService.getAll();
    }

    @Get(':id')
    public getSubmarineById(@Param('id', ParseIntPipe) id: number) {
        return this.submarinesService.getById(id);
    }

    @Post()
    public addSubmarine(@Body() dto: SubmarineDto) {
        return this.submarinesService.create(dto);
    }

    @Delete(':id')
    public deleteSubmarine(@Param('id', ParseIntPipe) id: number) {
        return this.submarinesService.remove(id);
    }

    @Put(':id')
    public updateSubmarine(@Param('id', ParseIntPipe) id: number, @Body() dto: SubmarineDto) {
        return this.submarinesService.update(id, dto);
    }

}
